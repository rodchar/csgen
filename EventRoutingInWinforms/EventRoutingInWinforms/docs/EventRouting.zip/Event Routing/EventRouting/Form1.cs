using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace EventRouting
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private EventRouting.UserControl1 userControl11;
        private EventRouting.UserControl2 userControl21;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
            this.userControl21.Click += new EventRouting.UserControl2.EventHandler(this.userControl_Click3);

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.userControl11 = new EventRouting.UserControl1();
            this.userControl21 = new EventRouting.UserControl2();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // userControl11
            // 
            this.userControl11.BackColor = System.Drawing.SystemColors.Info;
            this.userControl11.Location = new System.Drawing.Point(32, 48);
            this.userControl11.Name = "userControl11";
            this.userControl11.Size = new System.Drawing.Size(136, 150);
            this.userControl11.TabIndex = 0;
            this.userControl11.Click += new EventRouting.UserControl1.EventHandler(this.userControl_Click1);
            // 
            // userControl21
            // 
            this.userControl21.BackColor = System.Drawing.SystemColors.Info;
            this.userControl21.Location = new System.Drawing.Point(224, 48);
            this.userControl21.Name = "userControl21";
            this.userControl21.Size = new System.Drawing.Size(136, 150);
            this.userControl21.TabIndex = 1;
            this.userControl21.Click += new EventRouting.UserControl2.EventHandler(this.userControl_Click2);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(32, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "Routing to all handlers";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(224, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "Routing with event handling controlled";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(394, 245);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.userControl21);
            this.Controls.Add(this.userControl11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Event Routing Demo";
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void userControl_Click1(object sender, System.EventArgs e)
        {
            Control ctrl = sender as Control;
            MessageBox.Show(
                string.Format(
@"userControl11_Click
{0}, {1}",
                ctrl.Text,
                ctrl.GetType().FullName),
                this.Text);
        }


        private void userControl_Click2(object sender, EventRouting.EventArgs e)
        {
             Control ctrl = sender as Control;
             DialogResult result = MessageBox.Show(
                string.Format(
@"Click 'Yes' if you consider this event to be handled here.
userControl21_Click
{0}, {1}",
                ctrl.Text,
                ctrl.GetType().FullName),
                this.Text, MessageBoxButtons.YesNo);
            if(result == DialogResult.Yes)
                e.Handled = true;
        }
        private void userControl_Click3(object sender, EventRouting.EventArgs e)
        {
             Control ctrl = sender as Control;
             DialogResult result = MessageBox.Show(
                string.Format(
@"Click 'Yes' if you consider this event to be handled here.
userControl21_Click
{0}, {1}",
                ctrl.Text,
                ctrl.GetType().FullName),
                this.Text, MessageBoxButtons.YesNo);
            if(result == DialogResult.Yes)
                e.Handled = true;
        }    
	}
}
